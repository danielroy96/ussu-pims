CREATE VIEW item_details_current AS
  SELECT
    `id`.`id`                      AS `id`,
    `id`.`item_id`                 AS `item_id`,
    `id`.`start_datetime`          AS `start_datetime`,
    `id`.`end_datetime`            AS `end_datetime`,
    `id`.`status_control`          AS `status_control`,
    `id`.`status`                  AS `status`,
    `id`.`last_changed_by_user_id` AS `last_changed_by_user_id`,
    `id`.`barcode`                 AS `barcode`,
    `id`.`description`             AS `description`,
    `id`.`item_type`               AS `item_type`
  FROM `pims`.`item_details` `id`
  WHERE (`id`.`status_control` = 'C')
  ORDER BY `id`.`item_id`;

