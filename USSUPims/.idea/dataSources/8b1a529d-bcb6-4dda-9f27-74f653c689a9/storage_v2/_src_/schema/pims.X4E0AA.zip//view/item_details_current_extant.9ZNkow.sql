CREATE VIEW item_details_current_extant AS
  SELECT
    `item_details_current`.`id`                      AS `id`,
    `item_details_current`.`item_id`                 AS `item_id`,
    `item_details_current`.`start_datetime`          AS `start_datetime`,
    `item_details_current`.`end_datetime`            AS `end_datetime`,
    `item_details_current`.`status_control`          AS `status_control`,
    `item_details_current`.`status`                  AS `status`,
    `item_details_current`.`last_changed_by_user_id` AS `last_changed_by_user_id`,
    `item_details_current`.`barcode`                 AS `barcode`,
    `item_details_current`.`description`             AS `description`,
    `item_details_current`.`item_type`               AS `item_type`
  FROM `pims`.`item_details_current`
  WHERE (`item_details_current`.`status` = 'CURRENT');

