CREATE VIEW item_details_current_extant_in_date AS
  SELECT
    `idce`.`id`                      AS `id`,
    `idce`.`item_id`                 AS `item_id`,
    `idce`.`start_datetime`          AS `start_datetime`,
    `idce`.`end_datetime`            AS `end_datetime`,
    `idce`.`status_control`          AS `status_control`,
    `idce`.`status`                  AS `status`,
    `idce`.`last_changed_by_user_id` AS `last_changed_by_user_id`,
    `idce`.`barcode`                 AS `barcode`,
    `idce`.`description`             AS `description`,
    `idce`.`item_type`               AS `item_type`
  FROM ((`pims`.`item_details_current_extant` `idce`
    JOIN `pims`.`item_types` `it` ON ((`idce`.`item_type` = `it`.`id`))) JOIN `pims`.`tests_latest` `tl`
      ON ((`idce`.`item_id` = `tl`.`item_id`)))
  WHERE ((curdate() - INTERVAL `it`.`pat_interval_months` MONTH) > `tl`.`test_datetime`);

