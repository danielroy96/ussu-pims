CREATE VIEW tests_latest AS
  SELECT
    `t`.`id`                          AS `id`,
    `t`.`item_id`                     AS `item_id`,
    `t`.`test_datetime`               AS `test_datetime`,
    `t`.`test_user`                   AS `test_user`,
    `t`.`earth_resistance_ohms`       AS `earth_resistance_ohms`,
    `t`.`insulation_resistance_mohms` AS `insulation_resistance_mohms`
  FROM (`pims`.`tests` `t`
    JOIN (SELECT
            max(`t`.`id`) AS `id`,
            `t`.`item_id` AS `item_id`
          FROM `pims`.`tests` `t`
          GROUP BY `t`.`item_id`
          HAVING max(`t`.`id`)) `t2` ON ((`t`.`id` = `t2`.`id`)));

