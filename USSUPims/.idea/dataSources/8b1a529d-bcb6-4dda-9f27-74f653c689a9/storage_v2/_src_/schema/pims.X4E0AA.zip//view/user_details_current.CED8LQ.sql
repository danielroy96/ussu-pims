CREATE VIEW user_details_current AS
  SELECT
    `ud`.`id`                      AS `id`,
    `ud`.`user_id`                 AS `user_id`,
    `ud`.`start_datetime`          AS `start_datetime`,
    `ud`.`end_datetime`            AS `end_datetime`,
    `ud`.`status_control`          AS `status_control`,
    `ud`.`status`                  AS `status`,
    `ud`.`username`                AS `username`,
    `ud`.`password`                AS `password`,
    `ud`.`forename`                AS `forename`,
    `ud`.`surname`                 AS `surname`,
    `ud`.`title`                   AS `title`,
    `ud`.`user_role`               AS `user_role`,
    `ud`.`user_type`               AS `user_type`,
    `ud`.`last_changed_by_user_id` AS `last_changed_by_user_id`
  FROM `pims`.`user_details` `ud`
  WHERE (`ud`.`status_control` = 'C');

