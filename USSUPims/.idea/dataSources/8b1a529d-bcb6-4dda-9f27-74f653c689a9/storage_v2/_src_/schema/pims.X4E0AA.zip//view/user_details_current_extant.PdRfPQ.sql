CREATE VIEW user_details_current_extant AS
  SELECT
    `udc`.`id`                      AS `id`,
    `udc`.`user_id`                 AS `user_id`,
    `udc`.`start_datetime`          AS `start_datetime`,
    `udc`.`end_datetime`            AS `end_datetime`,
    `udc`.`status_control`          AS `status_control`,
    `udc`.`status`                  AS `status`,
    `udc`.`username`                AS `username`,
    `udc`.`password`                AS `password`,
    `udc`.`forename`                AS `forename`,
    `udc`.`surname`                 AS `surname`,
    `udc`.`title`                   AS `title`,
    `udc`.`user_role`               AS `user_role`,
    `udc`.`user_type`               AS `user_type`,
    `udc`.`last_changed_by_user_id` AS `last_changed_by_user_id`
  FROM `pims`.`user_details_current` `udc`
  WHERE (`udc`.`status` = 'CURRENT');

